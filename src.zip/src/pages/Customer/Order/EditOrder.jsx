import React from 'react'

const EditOrder = () => {
  return (
    <div>EditOrder</div>
  )
}

export default EditOrder