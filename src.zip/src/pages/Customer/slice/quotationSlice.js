import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../../../api";
import { successMessage, errorMessage, getErrorMessage } from "../../../toast";

// Fetch quotations with pagination
export const fetchQuotation = createAsyncThunk(
  "quotation/fetchQuotation",
  async ({ pageIndex, pageLimit }, { rejectWithValue }) => {
    try {
      const res = await api.get(`admin/quotation-order/get-data`, {
        params: {
          page: pageIndex + 1, 
          limit: pageLimit
        }
      });
      return {
        data: res.data.data,
        totalRecords: res.data.total || res.data.data.length
      };
    } catch (error) {
      const errMsg = getErrorMessage(error);
      errorMessage(errMsg);
      return rejectWithValue(errMsg);
    }
  }
);

// Add quotation
export const addQuotation = createAsyncThunk(
  "quotation/addQuotation",
  async (values, { rejectWithValue }) => {
    try {
      const res = await api.post(`admin/quotation-order/store`, values);
      successMessage(res.data.message);
      return res.data.data;
    } catch (error) {
      const errMsg = getErrorMessage(error);
      errorMessage(errMsg);
      return rejectWithValue(errMsg);
    }
  }
);

// Edit quotation
export const editQuotation = createAsyncThunk(
  "quotation/editQuotation",
  async (id, { rejectWithValue }) => {
    try {
      const res = await api.post(`admin/quotation-order/edit/${id}`);
      successMessage(res.data.message);
      return res.data.data;
    } catch (error) {
      const errMsg = getErrorMessage(error);
      errorMessage(errMsg);
      return rejectWithValue(errMsg);
    }
  }
);

// Update quotation
export const updateQuotation = createAsyncThunk(
  "quotation/updateQuotation",
  async (values, { rejectWithValue }) => {
    try {
      const res = await api.post(`admin/quotation-order/update/${values.id}`, values);
      successMessage(res.data.message);
      return res.data.data;
    } catch (error) {
      const errMsg = getErrorMessage(error);
      errorMessage(errMsg);
      return rejectWithValue(errMsg);
    }
  }
);

// Delete quotation
export const deleteQuotation = createAsyncThunk(
  "quotation/deleteQuotation",
  async (id, { rejectWithValue }) => {
    try {
      const res = await api.post(`admin/quotation-order/delete/${id}`);
      successMessage(res.data.message);
      return { id };
    } catch (error) {
      const errMsg = getErrorMessage(error);
      errorMessage(errMsg);
      return rejectWithValue(errMsg);
    }
  }
);

const quotationSlice = createSlice({
  name: "quotation",
  initialState: {
    data: [],
    selected: {},
    totalRecords: 0,
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Fetch quotations
      .addCase(fetchQuotation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchQuotation.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload.data || [];
        state.totalRecords = action.payload.totalRecords || 0;
      })
      .addCase(fetchQuotation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // Add quotation
      .addCase(addQuotation.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addQuotation.fulfilled, (state, action) => {
        state.loading = false;
        state.data.unshift(action.payload);
        state.totalRecords += 1;
      })
      .addCase(addQuotation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Edit quotation
      .addCase(editQuotation.fulfilled, (state, action) => {
        state.loading = false;
        state.selected = action.payload;
      })
      
      // Delete quotation
      .addCase(deleteQuotation.pending, (state) => {
        state.loading = true;
      })
      .addCase(deleteQuotation.fulfilled, (state, action) => {
        state.loading = false;
        state.data = state.data.filter(item => item.id !== action.payload.id);
        state.totalRecords = Math.max(0, state.totalRecords - 1);
      })
      .addCase(deleteQuotation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default quotationSlice.reducer;